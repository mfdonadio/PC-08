﻿using System; 
namespace PC_PrimerParcial_MarcoDonadio
{
    class Program
    {
        static void Main(string[]args)
        {
            double A;
            double B;
            double C; 
            Console.WriteLine("Bienvenido, ingrese su primer número: ");
            A = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese su segundo número: ");
            B = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese su tercer número: ");
            C = Convert.ToDouble(Console.ReadLine());

            if (A %2==0)
            {
                Console.WriteLine("El número "+(A)+" es par.");
            }
            else
            {
                Console.WriteLine("El número "+(A)+" es impar.");
            }

            if (B %2==0)
             {
                Console.WriteLine("El número "+(B)+" es par.");
            }
            else
            {
                Console.WriteLine("El número "+(B)+" es impar.");
            }

            if (C %2==0)
             {
                Console.WriteLine("El número "+(C)+" es par.");
            }
            else
            {
                Console.WriteLine("El número "+(C)+" es impar.");
            }

        }
    }
}